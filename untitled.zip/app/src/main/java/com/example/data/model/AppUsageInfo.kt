package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class AppCategory(val label: String, val isProductive: Boolean, val color: Color) {
    PRODUCTIVE("Produktivitas", true, Color(0xFF10B981)),
    EDUCATION("Belajar & Kuliah", true, Color(0xFF3B82F6)),
    SOCIAL("Sosial Media", false, Color(0xFFF59E0B)),
    ENTERTAINMENT("Hiburan & Video", false, Color(0xFFEC4899)),
    GAMES("Game", false, Color(0xFF8B5CF6)),
    OTHER("Lainnya", true, Color(0xFF64748B))
}

data class AppUsageInfo(
    val packageName: String,
    val appName: String,
    val totalTimeInForegroundMs: Long,
    val category: AppCategory,
    val formattedDuration: String,
    val usagePercentage: Float = 0f
)

data class ScreentimeSummary(
    val totalUsageMs: Long = 0L,
    val productiveMs: Long = 0L,
    val unproductiveMs: Long = 0L,
    val topApps: List<AppUsageInfo> = emptyList(),
    val hasUsageAccessPermission: Boolean = false,
    val isWarningTriggered: Boolean = false,
    val warningMessage: String = ""
) {
    val productivePercentage: Int
        get() = if (totalUsageMs > 0) ((productiveMs.toFloat() / totalUsageMs) * 100).toInt() else 0

    val unproductivePercentage: Int
        get() = if (totalUsageMs > 0) ((unproductiveMs.toFloat() / totalUsageMs) * 100).toInt() else 0
}
