package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.QuadrantDelegate
import com.example.ui.theme.QuadrantDoFirst
import com.example.ui.theme.QuadrantEliminate
import com.example.ui.theme.QuadrantSchedule

/**
 * Matriks Kuadran Eisenhower untuk pengelompokan otomatis tugas.
 */
enum class PriorityQuadrant(
    val title: String,
    val subtitle: String,
    val actionLabel: String,
    val color: Color
) {
    DO_FIRST(
        title = "Do First (Kerjakan Segera)",
        subtitle = "Mendesak & Sangat Penting",
        actionLabel = "Fokus Sekarang",
        color = QuadrantDoFirst
    ),
    SCHEDULE(
        title = "Schedule (Jadwalkan)",
        subtitle = "Penting tapi Tidak Mendesak",
        actionLabel = "Rencanakan",
        color = QuadrantSchedule
    ),
    DELEGATE(
        title = "Delegate (Sederhanakan/Delegasi)",
        subtitle = "Mendesak tapi Kurang Penting",
        actionLabel = "Cepat Selesaikan",
        color = QuadrantDelegate
    ),
    ELIMINATE(
        title = "Eliminate (Abaikan/Tunda)",
        subtitle = "Tidak Mendesak & Tidak Penting",
        actionLabel = "Nanti Saja",
        color = QuadrantEliminate
    )
}

/**
 * Hasil kalkulasi algoritma prioritas pintar untuk suatu tugas.
 */
data class TaskPriorityAnalysis(
    val taskId: Long,
    val urgencyScore: Float, // 1.0 .. 10.0
    val importanceScore: Float, // 1.0 .. 10.0
    val overallPriorityScore: Float, // Skala gabungan 0.0 .. 100.0
    val quadrant: PriorityQuadrant,
    val recommendationTag: String,
    val recommendationReason: String
)
