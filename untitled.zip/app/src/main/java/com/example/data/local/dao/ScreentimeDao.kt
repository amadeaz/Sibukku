package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.ScreentimeLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ScreentimeDao {

    @Query("SELECT * FROM screentime_logs WHERE dateKey = :dateKey ORDER BY totalTimeInForegroundMs DESC")
    fun getLogsForDate(dateKey: String): Flow<List<ScreentimeLogEntity>>

    @Query("SELECT SUM(totalTimeInForegroundMs) FROM screentime_logs WHERE dateKey = :dateKey")
    fun getTotalScreentimeForDate(dateKey: String): Flow<Long?>

    @Query("SELECT SUM(totalTimeInForegroundMs) FROM screentime_logs WHERE dateKey = :dateKey AND isProductive = 0")
    fun getUnproductiveScreentimeForDate(dateKey: String): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<ScreentimeLogEntity>)

    @Query("DELETE FROM screentime_logs WHERE dateKey = :dateKey")
    suspend fun clearLogsForDate(dateKey: String)
}
