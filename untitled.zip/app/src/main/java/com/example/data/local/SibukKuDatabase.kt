package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.CategoryDao
import com.example.data.local.dao.ScreentimeDao
import com.example.data.local.dao.TaskDao
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.ScreentimeLogEntity
import com.example.data.local.entity.TaskEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TaskEntity::class,
        CategoryEntity::class,
        ScreentimeLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SibukKuDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao
    abstract fun categoryDao(): CategoryDao
    abstract fun screentimeDao(): ScreentimeDao

    companion object {
        @Volatile
        private var INSTANCE: SibukKuDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): SibukKuDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SibukKuDatabase::class.java,
                    "sibukku_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(database: SibukKuDatabase) {
                val categoryDao = database.categoryDao()
                val taskDao = database.taskDao()

                // Kategori bawaan
                val defaultCategories = listOf(
                    CategoryEntity(id = 1, name = "Pendidikan / Sekolah", colorHex = "#4F46E5", iconName = "school", isProductive = true),
                    CategoryEntity(id = 2, name = "Pekerjaan / Bisnis", colorHex = "#06B6D4", iconName = "work", isProductive = true),
                    CategoryEntity(id = 3, name = "Kesehatan & Olahraga", colorHex = "#10B981", iconName = "fitness", isProductive = true),
                    CategoryEntity(id = 4, name = "Pribadi & Rumah", colorHex = "#F59E0B", iconName = "home", isProductive = true),
                    CategoryEntity(id = 5, name = "Hiburan & Santai", colorHex = "#8B5CF6", iconName = "movie", isProductive = false)
                )
                categoryDao.insertDefaultCategories(defaultCategories)

                // Tugas awal untuk mendemonstrasikan algoritma matriks prioritas & dashboard
                val currentTime = System.currentTimeMillis()
                val hour = 3600 * 1000L

                val sampleTasks = listOf(
                    TaskEntity(
                        title = "Selesaikan PR / Makalah Semester",
                        description = "Tugas wajib bab 1-3 dengan referensi jurnal ilmiah.",
                        categoryId = 1,
                        categoryName = "Pendidikan / Sekolah",
                        importanceLevel = 3, // Tinggi
                        deadlineTimestamp = currentTime + (5 * hour), // 5 jam lagi (Mendesak & Penting -> Do First)
                        estimatedMinutes = 90,
                        isCompleted = false
                    ),
                    TaskEntity(
                        title = "Siapkan Presentasi Proyek Kerja",
                        description = "Slide pitch deck untuk rapat evaluasi klien besok pagi.",
                        categoryId = 2,
                        categoryName = "Pekerjaan / Bisnis",
                        importanceLevel = 3, // Tinggi
                        deadlineTimestamp = currentTime + (22 * hour), // Besok
                        estimatedMinutes = 60,
                        isCompleted = false
                    ),
                    TaskEntity(
                        title = "Rencanakan Jadwal Olahraga Mingguan",
                        description = "Jogging dan kardio 30 menit per sesi.",
                        categoryId = 3,
                        categoryName = "Kesehatan & Olahraga",
                        importanceLevel = 2, // Sedang (Penting tapi tidak mendesak -> Schedule)
                        deadlineTimestamp = currentTime + (72 * hour), // 3 hari lagi
                        estimatedMinutes = 20,
                        isCompleted = false
                    ),
                    TaskEntity(
                        title = "Balas Email Konfirmasi & Jadwal Meeting",
                        description = "Respon undangan Zoom rekan tim.",
                        categoryId = 2,
                        categoryName = "Pekerjaan / Bisnis",
                        importanceLevel = 1, // Rendah (Mendesak tapi kurang penting -> Delegate)
                        deadlineTimestamp = currentTime + (3 * hour), // 3 jam lagi
                        estimatedMinutes = 15,
                        isCompleted = false
                    ),
                    TaskEntity(
                        title = "Cek Daftar Film yang Ingin Ditonton",
                        description = "Simpan ke wishlist untuk akhir pekan.",
                        categoryId = 5,
                        categoryName = "Hiburan & Santai",
                        importanceLevel = 1, // Rendah (Tidak mendesak & Tidak penting -> Eliminate)
                        deadlineTimestamp = currentTime + (120 * hour),
                        estimatedMinutes = 10,
                        isCompleted = false
                    )
                )
                taskDao.insertTasks(sampleTasks)
            }
        }
    }
}
