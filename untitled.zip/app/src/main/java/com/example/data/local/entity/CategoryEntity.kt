package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entitas Kategori untuk pengelompokan tugas dan analisis produktivitas.
 */
@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val colorHex: String = "#4F46E5",
    val iconName: String = "folder",
    val isProductive: Boolean = true
)
