package com.example.data.repository

import com.example.data.local.dao.TaskDao
import com.example.data.local.entity.TaskEntity
import kotlinx.coroutines.flow.Flow

class TaskRepository(private val taskDao: TaskDao) {

    fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks()

    fun getPendingTasks(): Flow<List<TaskEntity>> = taskDao.getPendingTasks()

    fun getTasksByCategory(categoryId: Long): Flow<List<TaskEntity>> =
        taskDao.getTasksByCategory(categoryId)

    fun getHighPriorityPendingCount(): Flow<Int> = taskDao.getHighPriorityPendingCount()

    fun getCompletedCount(): Flow<Int> = taskDao.getCompletedCount()

    suspend fun getTaskById(taskId: Long): TaskEntity? = taskDao.getTaskById(taskId)

    suspend fun insertTask(task: TaskEntity): Long = taskDao.insertTask(task)

    suspend fun updateTask(task: TaskEntity) = taskDao.updateTask(task)

    suspend fun deleteTask(task: TaskEntity) = taskDao.deleteTask(task)

    suspend fun deleteTaskById(taskId: Long) = taskDao.deleteTaskById(taskId)

    suspend fun toggleTaskCompletion(task: TaskEntity) {
        val newStatus = !task.isCompleted
        val completedAt = if (newStatus) System.currentTimeMillis() else null
        taskDao.updateTaskStatus(task.id, newStatus, completedAt)
    }
}
