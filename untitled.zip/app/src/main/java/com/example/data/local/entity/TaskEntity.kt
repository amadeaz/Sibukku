package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entitas database untuk Tugas dan Jadwal SibukKu.
 * Mendukung prioritas berjenjang (1: Rendah, 2: Sedang, 3: Tinggi),
 * estimasi waktu kerja, tenggat waktu (deadline), dan pengingat.
 */
@Entity(
    tableName = "tasks",
    indices = [
        Index(value = ["isCompleted"]),
        Index(value = ["deadlineTimestamp"]),
        Index(value = ["categoryId"])
    ]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val categoryId: Long = 1,
    val categoryName: String = "Umum",
    val importanceLevel: Int = 2, // 1: Rendah, 2: Sedang, 3: Tinggi (Krusial)
    val deadlineTimestamp: Long? = null, // Epoch millis
    val estimatedMinutes: Int = 30, // Estimasi durasi pengerjaan dalam menit
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val reminderMinutesBefore: Int? = 30 // Notifikasi 30 menit sebelum deadline
)
