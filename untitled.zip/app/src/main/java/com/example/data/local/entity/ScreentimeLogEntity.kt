package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Entitas cache data screentime harian yang diambil dari Android UsageStatsManager
 * atau dicatat untuk analisis tren digital wellbeing pengguna.
 */
@Entity(
    tableName = "screentime_logs",
    indices = [
        Index(value = ["dateKey", "packageName"], unique = true)
    ]
)
data class ScreentimeLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateKey: String, // Format "yyyy-MM-dd"
    val packageName: String,
    val appName: String,
    val totalTimeInForegroundMs: Long,
    val isProductive: Boolean,
    val category: String, // "PRODUKTIF", "SOSIAL", "HIBURAN", "GAME", "LAINNYA"
    val lastTimeUsed: Long = System.currentTimeMillis()
)
