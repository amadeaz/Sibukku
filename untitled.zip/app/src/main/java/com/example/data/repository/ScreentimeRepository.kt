package com.example.data.repository

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Process
import com.example.data.local.dao.ScreentimeDao
import com.example.data.local.entity.ScreentimeLogEntity
import com.example.data.model.AppCategory
import com.example.data.model.AppUsageInfo
import com.example.data.model.ScreentimeSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ScreentimeRepository(
    private val context: Context,
    private val screentimeDao: ScreentimeDao
) {

    private val packageManager: PackageManager = context.packageManager

    /**
     * Memeriksa apakah izin PACKAGE_USAGE_STATS telah diberikan oleh pengguna melalui pengaturan sistem.
     */
    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Mengambil ringkasan penggunaan screentime harian.
     * Jika izin aktif, membaca langsung dari Android UsageStatsManager.
     * Jika belum aktif, menyajikan preview data simulasi digital wellbeing agar antarmuka tetap informatif.
     */
    suspend fun getDailyScreentime(highPriorityPendingCount: Int): ScreentimeSummary =
        withContext(Dispatchers.IO) {
            val isPermissionGranted = hasUsageStatsPermission()
            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val startOfDay = calendar.timeInMillis
            val now = System.currentTimeMillis()
            val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            val appList = mutableListOf<AppUsageInfo>()

            if (isPermissionGranted) {
                val usageStatsManager =
                    context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                if (usageStatsManager != null) {
                    val aggregate = usageStatsManager.queryAndAggregateUsageStats(startOfDay, now)
                    for ((pkg, stats) in aggregate) {
                        val duration = stats.totalTimeInForeground
                        if (duration > 60_000L) { // Tampilkan hanya aplikasi aktif > 1 menit
                            val appName = try {
                                val appInfo = packageManager.getApplicationInfo(pkg, 0)
                                packageManager.getApplicationLabel(appInfo).toString()
                            } catch (e: Exception) {
                                pkg.substringAfterLast('.')
                            }
                            val category = classifyPackage(pkg, appName)
                            appList.add(
                                AppUsageInfo(
                                    packageName = pkg,
                                    appName = appName,
                                    totalTimeInForegroundMs = duration,
                                    category = category,
                                    formattedDuration = formatDuration(duration)
                                )
                            )
                        }
                    }
                }
            }

            // Jika izin belum ada atau belum ada riwayat aplikasi, sediakan benchmark data informatif
            if (appList.isEmpty()) {
                appList.addAll(getDemoAppUsageList())
            }

            appList.sortByDescending { it.totalTimeInForegroundMs }

            val totalDuration = appList.sumOf { it.totalTimeInForegroundMs }
            val productiveDuration = appList.filter { it.category.isProductive }
                .sumOf { it.totalTimeInForegroundMs }
            val unproductiveDuration = totalDuration - productiveDuration

            // Normalisasi persentase
            val finalizedList = appList.map {
                it.copy(
                    usagePercentage = if (totalDuration > 0) {
                        (it.totalTimeInForegroundMs.toFloat() / totalDuration)
                    } else 0f
                )
            }

            // Simpan cache log harian ke database Room
            val logs = finalizedList.take(10).map {
                ScreentimeLogEntity(
                    dateKey = dateKey,
                    packageName = it.packageName,
                    appName = it.appName,
                    totalTimeInForegroundMs = it.totalTimeInForegroundMs,
                    isProductive = it.category.isProductive,
                    category = it.category.label,
                    lastTimeUsed = now
                )
            }
            screentimeDao.insertLogs(logs)

            // Logika Deteksi Peringatan (Warning Nudge):
            // Jika waktu penggunaan aplikasi non-produktif > 1 jam 15 menit (4.500.000 ms)
            // DAN ada tugas berprioritas tinggi yang belum diselesaikan
            val warningThresholdMs = 75 * 60 * 1000L
            val isWarningTriggered = (unproductiveDuration >= warningThresholdMs) && (highPriorityPendingCount > 0)
            val warningMessage = if (isWarningTriggered) {
                "Perhatian: Kamu sudah menghabiskan ${formatDuration(unproductiveDuration)} di aplikasi hiburan/sosial, padahal ada $highPriorityPendingCount tugas penting belum selesai! Yuk fokus tuntaskan tugasmu."
            } else ""

            ScreentimeSummary(
                totalUsageMs = totalDuration,
                productiveMs = productiveDuration,
                unproductiveMs = unproductiveDuration,
                topApps = finalizedList.take(6),
                hasUsageAccessPermission = isPermissionGranted,
                isWarningTriggered = isWarningTriggered,
                warningMessage = warningMessage
            )
        }

    private fun classifyPackage(pkg: String, name: String): AppCategory {
        val combined = "${pkg.lowercase()} ${name.lowercase()}"
        return when {
            combined.contains("instagram") || combined.contains("tiktok") ||
                combined.contains("twitter") || combined.contains("facebook") ||
                combined.contains("reddit") || combined.contains("social") ||
                combined.contains("threads") || combined.contains("snapchat") -> AppCategory.SOCIAL

            combined.contains("youtube") || combined.contains("netflix") ||
                combined.contains("spotify") || combined.contains("twitch") ||
                combined.contains("disney") || combined.contains("video") ||
                combined.contains("movie") || combined.contains("music") -> AppCategory.ENTERTAINMENT

            combined.contains("game") || combined.contains("mobile") ||
                combined.contains("roblox") || combined.contains("genshin") ||
                combined.contains("moonton") -> AppCategory.GAMES

            combined.contains("classroom") || combined.contains("duolingo") ||
                combined.contains("study") || combined.contains("kamus") ||
                combined.contains("coursera") || combined.contains("udemy") -> AppCategory.EDUCATION

            combined.contains("notion") || combined.contains("keep") ||
                combined.contains("docs") || combined.contains("sheets") ||
                combined.contains("slides") || combined.contains("drive") ||
                combined.contains("slack") || combined.contains("teams") ||
                combined.contains("zoom") || combined.contains("sibukku") -> AppCategory.PRODUCTIVE

            else -> AppCategory.OTHER
        }
    }

    private fun getDemoAppUsageList(): List<AppUsageInfo> {
        val min = 60 * 1000L
        return listOf(
            AppUsageInfo(
                packageName = "com.google.android.apps.docs",
                appName = "Google Docs / Materi Kuliah",
                totalTimeInForegroundMs = 52 * min,
                category = AppCategory.PRODUCTIVE,
                formattedDuration = "52m"
            ),
            AppUsageInfo(
                packageName = "com.instagram.android",
                appName = "Instagram",
                totalTimeInForegroundMs = 85 * min,
                category = AppCategory.SOCIAL,
                formattedDuration = "1j 25m"
            ),
            AppUsageInfo(
                packageName = "com.google.android.youtube",
                appName = "YouTube Video",
                totalTimeInForegroundMs = 45 * min,
                category = AppCategory.ENTERTAINMENT,
                formattedDuration = "45m"
            ),
            AppUsageInfo(
                packageName = "com.sibukku.app",
                appName = "SibukKu Planner",
                totalTimeInForegroundMs = 30 * min,
                category = AppCategory.PRODUCTIVE,
                formattedDuration = "30m"
            )
        )
    }

    private fun formatDuration(millis: Long): String {
        val hours = millis / (1000 * 60 * 60)
        val minutes = (millis % (1000 * 60 * 60)) / (1000 * 60)
        return when {
            hours > 0 && minutes > 0 -> "${hours}j ${minutes}m"
            hours > 0 -> "${hours}j"
            minutes > 0 -> "${minutes}m"
            else -> "< 1m"
        }
    }
}
