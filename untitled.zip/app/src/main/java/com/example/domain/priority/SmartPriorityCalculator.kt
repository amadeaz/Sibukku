package com.example.domain.priority

import com.example.data.local.entity.TaskEntity
import com.example.data.model.PriorityQuadrant
import com.example.data.model.TaskPriorityAnalysis
import java.util.concurrent.TimeUnit

/**
 * Algoritma Penentuan Skala Prioritas Pintar (Smart Priority Matrix).
 *
 * Logika Skoring:
 * 1. Urgency Score (1.0 - 10.0):
 *    - Dihitung dari sisa waktu menuju tenggat waktu (deadline).
 *    - Lewat deadline (Overdue) -> 10.0 (Maksimal)
 *    - < 6 Jam -> 9.5
 *    - < 24 Jam -> 8.5
 *    - < 3 Hari -> 6.5
 *    - < 7 Hari -> 4.5
 *    - > 7 Hari / Tanpa Deadline -> 2.5
 *
 * 2. Importance Score (1.0 - 10.0):
 *    - Didasarkan pada level kepentingan pilihan pengguna:
 *      Tinggi (Krusial) = 8.5, Sedang = 6.0, Rendah = 3.0
 *    - Ditambah Contextual Keyword Boost (+1.0 s/d +1.5) jika mengandung kata kunci kritis
 *      seperti "PR", "ujian", "skripsi", "tugas", "deadline", "klien", "laporan".
 *    - Kategori produktif penting (Sekolah/Pekerjaan) mendapat penguatan skor.
 *
 * 3. Overall Priority Score (0 - 100):
 *    Skor gabungan terbobot: (UrgencyScore * 0.55 + ImportanceScore * 0.45) * 10
 *
 * 4. Pemetaan Kuadran Eisenhower:
 *    - Urgensi >= 6.0 & Penting >= 6.0 -> Kuadran 1: Do First (Kerjakan Segera)
 *    - Urgensi < 6.0 & Penting >= 6.0  -> Kuadran 2: Schedule (Jadwalkan)
 *    - Urgensi >= 6.0 & Penting < 6.0  -> Kuadran 3: Delegate (Delegasikan / Tuntaskan Cepat)
 *    - Urgensi < 6.0 & Penting < 6.0   -> Kuadran 4: Eliminate (Tunda / Abaikan)
 */
object SmartPriorityCalculator {

    private val CRITICAL_KEYWORDS = listOf(
        "pr", "ujian", "skripsi", "tugas", "deadline", "klien", "laporan",
        "presentasi", "evaluasi", "sidang", "urgent", "proposal", "uts", "uas"
    )

    fun calculatePriority(
        task: TaskEntity,
        currentTimeMillis: Long = System.currentTimeMillis()
    ): TaskPriorityAnalysis {
        // 1. Hitung Skor Urgensi
        val urgencyScore = calculateUrgencyScore(task.deadlineTimestamp, currentTimeMillis)

        // 2. Hitung Skor Kepentingan (Importance)
        val importanceScore = calculateImportanceScore(task)

        // 3. Skor Gabungan (0 - 100)
        val weightedScore = (urgencyScore * 0.55f + importanceScore * 0.45f) * 10f
        val overallScore = weightedScore.coerceIn(0f, 100f)

        // 4. Tentukan Kuadran Eisenhower
        val isUrgent = urgencyScore >= 6.0f
        val isImportant = importanceScore >= 6.0f

        val quadrant = when {
            isUrgent && isImportant -> PriorityQuadrant.DO_FIRST
            !isUrgent && isImportant -> PriorityQuadrant.SCHEDULE
            isUrgent && !isImportant -> PriorityQuadrant.DELEGATE
            else -> PriorityQuadrant.ELIMINATE
        }

        // 5. Rekomendasi Tag & Alasan
        val (tag, reason) = generateRecommendation(task, urgencyScore, importanceScore, quadrant)

        return TaskPriorityAnalysis(
            taskId = task.id,
            urgencyScore = urgencyScore,
            importanceScore = importanceScore,
            overallPriorityScore = overallScore,
            quadrant = quadrant,
            recommendationTag = tag,
            recommendationReason = reason
        )
    }

    private fun calculateUrgencyScore(deadline: Long?, currentTime: Long): Float {
        if (deadline == null) return 2.5f

        val diffMillis = deadline - currentTime
        if (diffMillis <= 0) {
            // Sudah lewat tenggat waktu!
            return 10.0f
        }

        val diffHours = TimeUnit.MILLISECONDS.toHours(diffMillis)
        return when {
            diffHours <= 6 -> 9.5f
            diffHours <= 12 -> 9.0f
            diffHours <= 24 -> 8.5f
            diffHours <= 48 -> 7.0f
            diffHours <= 72 -> 6.0f
            diffHours <= 168 -> 4.5f // Dalam 1 minggu
            else -> 2.5f
        }
    }

    private fun calculateImportanceScore(task: TaskEntity): Float {
        // Base score dari level pilihan user
        var score = when (task.importanceLevel) {
            3 -> 8.5f // Tinggi
            2 -> 6.0f // Sedang
            else -> 3.5f // Rendah
        }

        // Kategori boost (Pendidikan / Pekerjaan)
        val lowerCategory = task.categoryName.lowercase()
        if (lowerCategory.contains("pendidikan") || lowerCategory.contains("sekolah") ||
            lowerCategory.contains("pekerjaan") || lowerCategory.contains("bisnis")
        ) {
            score += 1.0f
        }

        // Keyword boost
        val content = "${task.title} ${task.description}".lowercase()
        val hasCriticalKeyword = CRITICAL_KEYWORDS.any { content.contains(it) }
        if (hasCriticalKeyword) {
            score += 1.0f
        }

        return score.coerceIn(1.0f, 10.0f)
    }

    private fun generateRecommendation(
        task: TaskEntity,
        urgency: Float,
        importance: Float,
        quadrant: PriorityQuadrant
    ): Pair<String, String> {
        return when (quadrant) {
            PriorityQuadrant.DO_FIRST -> {
                if (urgency >= 9.0f) {
                    "🔥 KRUSIAL HARI INI" to "Tenggat waktu sangat dekat dan dampaknya besar! Selesaikan ini sebelum yang lain."
                } else {
                    "⚡ SEGERA KERJAKAN" to "Tugas penting berprioritas tinggi dengan deadline mendatang."
                }
            }
            PriorityQuadrant.SCHEDULE -> {
                "📅 JADWALKAN FOKUS" to "Penting untuk tujuan jangka panjangmu. Atur blok waktu khusus agar tidak menumpuk."
            }
            PriorityQuadrant.DELEGATE -> {
                "⏳ TUNTASKAN CEPAT" to "Mendesak tetapi sederhana. Selesaikan dalam 15-30 menit atau sederhanakan."
            }
            PriorityQuadrant.ELIMINATE -> {
                "💤 TUNDA / OPSIONAL" to "Bukan prioritas utama saat ini. Bisa dikerjakan saat waktu luang."
            }
        }
    }
}
