package com.example.ui.matrix

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PriorityQuadrant
import com.example.ui.components.TaskItemCard
import com.example.ui.theme.PrimaryIndigo
import com.example.ui.viewmodel.DashboardUiState
import com.example.ui.viewmodel.MainViewModel

@Composable
fun EisenhowerMatrixScreen(
    viewModel: MainViewModel,
    uiState: DashboardUiState,
    modifier: Modifier = Modifier
) {
    var selectedQuadrant by remember { mutableStateOf<PriorityQuadrant?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("matrix_screen_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title & Description
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = PrimaryIndigo,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Matriks Prioritas Eisenhower",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Algoritma SibukKu otomatis mengkategorikan setiap tugas berdasarkan tenggat waktu (urgensi) dan tingkat kepentingannya.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 2x2 Interactive Grid
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Baris Atas: Do First & Schedule
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val q1Tasks = uiState.matrixTasks[PriorityQuadrant.DO_FIRST].orEmpty()
                    QuadrantCard(
                        quadrant = PriorityQuadrant.DO_FIRST,
                        taskCount = q1Tasks.size,
                        isSelected = selectedQuadrant == PriorityQuadrant.DO_FIRST,
                        onClick = {
                            selectedQuadrant = if (selectedQuadrant == PriorityQuadrant.DO_FIRST) null else PriorityQuadrant.DO_FIRST
                        },
                        modifier = Modifier.weight(1f)
                    )

                    val q2Tasks = uiState.matrixTasks[PriorityQuadrant.SCHEDULE].orEmpty()
                    QuadrantCard(
                        quadrant = PriorityQuadrant.SCHEDULE,
                        taskCount = q2Tasks.size,
                        isSelected = selectedQuadrant == PriorityQuadrant.SCHEDULE,
                        onClick = {
                            selectedQuadrant = if (selectedQuadrant == PriorityQuadrant.SCHEDULE) null else PriorityQuadrant.SCHEDULE
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Baris Bawah: Delegate & Eliminate
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val q3Tasks = uiState.matrixTasks[PriorityQuadrant.DELEGATE].orEmpty()
                    QuadrantCard(
                        quadrant = PriorityQuadrant.DELEGATE,
                        taskCount = q3Tasks.size,
                        isSelected = selectedQuadrant == PriorityQuadrant.DELEGATE,
                        onClick = {
                            selectedQuadrant = if (selectedQuadrant == PriorityQuadrant.DELEGATE) null else PriorityQuadrant.DELEGATE
                        },
                        modifier = Modifier.weight(1f)
                    )

                    val q4Tasks = uiState.matrixTasks[PriorityQuadrant.ELIMINATE].orEmpty()
                    QuadrantCard(
                        quadrant = PriorityQuadrant.ELIMINATE,
                        taskCount = q4Tasks.size,
                        isSelected = selectedQuadrant == PriorityQuadrant.ELIMINATE,
                        onClick = {
                            selectedQuadrant = if (selectedQuadrant == PriorityQuadrant.ELIMINATE) null else PriorityQuadrant.ELIMINATE
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Penjelasan Algoritma Skoring
        item {
            AlgorithmExplanationCard()
        }

        // Daftar Tugas Terfilter berdasarkan Kuadran yang Dipilih
        val activeQuadrant = selectedQuadrant
        val tasksInQuadrant = if (activeQuadrant != null) {
            uiState.matrixTasks[activeQuadrant].orEmpty()
        } else {
            uiState.matrixTasks[PriorityQuadrant.DO_FIRST].orEmpty()
        }

        item {
            val titleQuadrant = activeQuadrant ?: PriorityQuadrant.DO_FIRST
            Text(
                text = "Tugas dalam ${titleQuadrant.title} (${tasksInQuadrant.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = titleQuadrant.color
            )
        }

        if (tasksInQuadrant.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ) {
                    Text(
                        text = "Tidak ada tugas aktif dalam kuadran ini.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            }
        } else {
            items(
                items = tasksInQuadrant,
                key = { it.task.id }
            ) { item ->
                TaskItemCard(
                    task = item.task,
                    priority = item.priority,
                    onToggle = { viewModel.toggleTask(item.task) },
                    onDelete = { viewModel.deleteTask(item.task) }
                )
            }
        }
    }
}

@Composable
private fun QuadrantCard(
    quadrant: PriorityQuadrant,
    taskCount: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("quadrant_card_${quadrant.name}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) quadrant.color.copy(alpha = 0.18f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(quadrant.color)
                )
                Text(
                    text = "$taskCount tugas",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = quadrant.color
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = quadrant.actionLabel,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = quadrant.color
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = quadrant.subtitle,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AlgorithmExplanationCard() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp)),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = PrimaryIndigo,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Rumus Skoring AI SibukKu",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Skor Prioritas = (Urgensi × 55%) + (Tingkat Kepentingan × 45%)\n" +
                    "• Urgensi: Sisa waktu ke deadline (< 6 jam = 9.5/10, lewat deadline = 10/10).\n" +
                    "• Kepentingan: Level pilihan + Kata kunci krusial (PR, Ujian, Deadline, Klien) + Kategori produktif.",
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
