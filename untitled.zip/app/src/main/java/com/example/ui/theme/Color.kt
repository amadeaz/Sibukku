package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Indigo & Teal Theme with Vibrant Accents
val PrimaryIndigo = Color(0xFF4F46E5)
val PrimaryIndigoDark = Color(0xFF3730A3)
val PrimaryIndigoLight = Color(0xFF818CF8)

val SecondaryCyan = Color(0xFF06B6D4)
val SecondaryCyanDark = Color(0xFF0891B2)

val TertiaryAmber = Color(0xFFF59E0B)
val UrgentRed = Color(0xFFEF4444)
val SuccessGreen = Color(0xFF10B981)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFF475569)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

// Priority Quadrant Colors
val QuadrantDoFirst = Color(0xFFEF4444)
val QuadrantSchedule = Color(0xFF3B82F6)
val QuadrantDelegate = Color(0xFFF59E0B)
val QuadrantEliminate = Color(0xFF64748B)
