package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.TaskEntity
import com.example.ui.theme.PrimaryIndigo
import com.example.ui.theme.UrgentRed

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditTaskDialog(
    categories: List<CategoryEntity>,
    taskToEdit: TaskEntity? = null,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        description: String,
        categoryId: Long,
        categoryName: String,
        importanceLevel: Int,
        deadlineTimestamp: Long?,
        estimatedMinutes: Int
    ) -> Unit
) {
    val currentTime = System.currentTimeMillis()
    val hour = 3600 * 1000L

    var title by remember { mutableStateOf(taskToEdit?.title ?: "") }
    var description by remember { mutableStateOf(taskToEdit?.description ?: "") }
    var selectedCategoryId by remember {
        mutableLongStateOf(taskToEdit?.categoryId ?: (categories.firstOrNull()?.id ?: 1L))
    }
    var importanceLevel by remember { mutableIntStateOf(taskToEdit?.importanceLevel ?: 2) }
    var deadlineTimestamp by remember {
        mutableStateOf(taskToEdit?.deadlineTimestamp ?: (currentTime + 24 * hour))
    }
    var estimatedMinutes by remember { mutableIntStateOf(taskToEdit?.estimatedMinutes ?: 30) }
    var isTitleError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (taskToEdit == null) "Tambah Tugas Baru" else "Edit Tugas",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Input Judul
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        if (it.isNotBlank()) isTitleError = false
                    },
                    label = { Text("Judul Tugas (Contoh: PR Kalkulus, Laporan)") },
                    isError = isTitleError,
                    supportingText = {
                        if (isTitleError) {
                            Text("Judul tidak boleh kosong!", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_task_title"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Input Deskripsi
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Deskripsi / Catatan Tambahan (Opsional)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_task_desc"),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Pilih Kategori
                Text(
                    text = "Kategori",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = selectedCategoryId == cat.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) PrimaryIndigo
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { selectedCategoryId = cat.id }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cat.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tingkat Kepentingan (Importance)
                Text(
                    text = "Tingkat Kepentingan",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        Triple(1, "Rendah", Color(0xFF64748B)),
                        Triple(2, "Sedang", Color(0xFF0891B2)),
                        Triple(3, "Tinggi (Krusial)", UrgentRed)
                    ).forEach { (level, label, color) ->
                        val isSelected = importanceLevel == level
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) color else color.copy(alpha = 0.12f)
                                )
                                .clickable { importanceLevel = level }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (isSelected) Color.White else color
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tenggat Waktu (Deadline Shortcut)
                Text(
                    text = "Tenggat Waktu (Deadline)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "4 Jam Lagi" to (currentTime + 4 * hour),
                        "Hari Ini (+8j)" to (currentTime + 8 * hour),
                        "Besok (+24j)" to (currentTime + 24 * hour),
                        "3 Hari Lagi" to (currentTime + 72 * hour),
                        "1 Minggu" to (currentTime + 168 * hour)
                    ).forEach { (label, timestamp) ->
                        val isSelected = deadlineTimestamp?.let { Math.abs(it - timestamp) < (2 * hour) } ?: false
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { deadlineTimestamp = timestamp }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Estimasi Waktu Pengerjaan
                Text(
                    text = "Estimasi Pengerjaan: $estimatedMinutes menit",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(15, 30, 45, 60, 90).forEach { mins ->
                        val isSelected = estimatedMinutes == mins
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) PrimaryIndigo else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { estimatedMinutes = mins }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${mins}m",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        isTitleError = true
                    } else {
                        val categoryName = categories.find { it.id == selectedCategoryId }?.name ?: "Umum"
                        onSave(
                            title.trim(),
                            description.trim(),
                            selectedCategoryId,
                            categoryName,
                            importanceLevel,
                            deadlineTimestamp,
                            estimatedMinutes
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                modifier = Modifier.testTag("btn_save_task")
            ) {
                Text("Simpan Tugas")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
