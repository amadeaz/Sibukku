package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.model.PriorityQuadrant
import com.example.data.model.ScreentimeSummary
import com.example.data.model.TaskPriorityAnalysis
import com.example.data.repository.CategoryRepository
import com.example.data.repository.ScreentimeRepository
import com.example.data.repository.TaskRepository
import com.example.domain.notification.NotificationScheduler
import com.example.domain.priority.SmartPriorityCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TaskWithPriority(
    val task: TaskEntity,
    val priority: TaskPriorityAnalysis
)

data class DashboardUiState(
    val topPriorityTasks: List<TaskWithPriority> = emptyList(),
    val allTasksWithPriority: List<TaskWithPriority> = emptyList(),
    val filteredTasks: List<TaskWithPriority> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val screentimeSummary: ScreentimeSummary = ScreentimeSummary(),
    val selectedCategoryId: Long? = null,
    val searchQuery: String = "",
    val highPriorityPendingCount: Int = 0,
    val completedCount: Int = 0,
    val matrixTasks: Map<PriorityQuadrant, List<TaskWithPriority>> = emptyMap()
)

class MainViewModel(
    private val taskRepository: TaskRepository,
    private val categoryRepository: CategoryRepository,
    private val screentimeRepository: ScreentimeRepository,
    private val notificationScheduler: NotificationScheduler
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<Long?>(null)
    val selectedCategoryId = _selectedCategoryId.asStateFlow()

    private val _screentimeSummary = MutableStateFlow(ScreentimeSummary())
    val screentimeSummary = _screentimeSummary.asStateFlow()

    val categories: StateFlow<List<CategoryEntity>> = categoryRepository.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uiState: StateFlow<DashboardUiState> = combine(
        taskRepository.getAllTasks(),
        categoryRepository.getAllCategories(),
        _screentimeSummary,
        _selectedCategoryId,
        _searchQuery
    ) { tasks, cats, screentime, selectedCategory, query ->
        val now = System.currentTimeMillis()

        // Hitung skor prioritas pintar untuk semua tugas
        val tasksWithPriority = tasks.map { task ->
            val priority = SmartPriorityCalculator.calculatePriority(task, now)
            TaskWithPriority(task, priority)
        }

        // Top Priority Recommendations (hanya tugas belum selesai, diurutkan skor tertinggi)
        val pendingPriorities = tasksWithPriority
            .filter { !it.task.isCompleted }
            .sortedByDescending { it.priority.overallPriorityScore }

        val topPriority = pendingPriorities.take(3)

        // Filter berdasarkan kategori dan pencarian kata kunci
        val filtered = tasksWithPriority.filter { item ->
            val matchesCategory = selectedCategory == null || item.task.categoryId == selectedCategory
            val matchesSearch = query.isBlank() ||
                item.task.title.contains(query, ignoreCase = true) ||
                item.task.description.contains(query, ignoreCase = true)
            matchesCategory && matchesSearch
        }

        // Matriks 4 Kuadran
        val matrix = PriorityQuadrant.values().associateWith { quad ->
            tasksWithPriority.filter { !it.task.isCompleted && it.priority.quadrant == quad }
        }

        val highPending = tasks.count { !it.isCompleted && it.importanceLevel == 3 }
        val completed = tasks.count { it.isCompleted }

        DashboardUiState(
            topPriorityTasks = topPriority,
            allTasksWithPriority = tasksWithPriority,
            filteredTasks = filtered,
            categories = cats,
            screentimeSummary = screentime,
            selectedCategoryId = selectedCategory,
            searchQuery = query,
            highPriorityPendingCount = highPending,
            completedCount = completed,
            matrixTasks = matrix
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    init {
        refreshScreentime()
    }

    fun refreshScreentime() {
        viewModelScope.launch {
            val highPending = uiState.value.highPriorityPendingCount
            val summary = screentimeRepository.getDailyScreentime(highPending)
            _screentimeSummary.value = summary
        }
    }

    fun setCategoryFilter(categoryId: Long?) {
        _selectedCategoryId.value = categoryId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            taskRepository.toggleTaskCompletion(task)
            if (!task.isCompleted) {
                // Saat ditandai selesai, batalkan alarm pengingat
                notificationScheduler.cancelTaskReminder(task.id)
            } else {
                // Jika dibuka kembali dan ada deadline, jadwalkan kembali
                notificationScheduler.scheduleTaskReminder(task)
            }
            refreshScreentime()
        }
    }

    fun saveTask(
        id: Long = 0,
        title: String,
        description: String,
        categoryId: Long,
        categoryName: String,
        importanceLevel: Int,
        deadlineTimestamp: Long?,
        estimatedMinutes: Int
    ) {
        viewModelScope.launch {
            val taskEntity = TaskEntity(
                id = id,
                title = title,
                description = description,
                categoryId = categoryId,
                categoryName = categoryName,
                importanceLevel = importanceLevel,
                deadlineTimestamp = deadlineTimestamp,
                estimatedMinutes = estimatedMinutes,
                isCompleted = false
            )
            val newId = taskRepository.insertTask(taskEntity)
            val savedTask = if (id == 0L) taskEntity.copy(id = newId) else taskEntity
            notificationScheduler.scheduleTaskReminder(savedTask)
            refreshScreentime()
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            notificationScheduler.cancelTaskReminder(task.id)
            taskRepository.deleteTask(task)
            refreshScreentime()
        }
    }
}
