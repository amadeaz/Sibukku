package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.data.local.SibukKuDatabase
import com.example.data.repository.CategoryRepository
import com.example.data.repository.ScreentimeRepository
import com.example.data.repository.TaskRepository
import com.example.domain.notification.NotificationScheduler
import com.example.receiver.TaskReminderReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class SibukKuApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database by lazy { SibukKuDatabase.getDatabase(this, applicationScope) }
    val taskRepository by lazy { TaskRepository(database.taskDao()) }
    val categoryRepository by lazy { CategoryRepository(database.categoryDao()) }
    val screentimeRepository by lazy { ScreentimeRepository(this, database.screentimeDao()) }
    val notificationScheduler by lazy { NotificationScheduler(this) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                TaskReminderReceiver.CHANNEL_ID,
                TaskReminderReceiver.CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Pengingat tenggat waktu tugas prioritas SibukKu"
                enableVibration(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
