package com.example

import com.example.data.local.entity.TaskEntity
import com.example.data.model.PriorityQuadrant
import com.example.domain.priority.SmartPriorityCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartPriorityCalculatorTest {

    @Test
    fun testUrgentAndImportantTaskAssignedToDoFirst() {
        val now = 1700000000000L
        val task = TaskEntity(
            id = 1,
            title = "PR Matematika Bab 3",
            description = "Tugas wajib dikumpul sebelum jam 12",
            categoryId = 1,
            categoryName = "Pendidikan",
            importanceLevel = 3, // Tinggi
            deadlineTimestamp = now + (3 * 3600 * 1000L), // 3 jam lagi
            isCompleted = false
        )

        val result = SmartPriorityCalculator.calculatePriority(task, currentTimeMillis = now)

        assertEquals(PriorityQuadrant.DO_FIRST, result.quadrant)
        assertTrue(result.urgencyScore >= 9.0f)
        assertTrue(result.importanceScore >= 8.5f)
        assertTrue(result.overallPriorityScore >= 80f)
    }

    @Test
    fun testNotUrgentImportantTaskAssignedToSchedule() {
        val now = 1700000000000L
        val task = TaskEntity(
            id = 2,
            title = "Rencana Strategi Bisnis Kuartal",
            description = "Penyusunan target tahunan",
            categoryId = 2,
            categoryName = "Pekerjaan",
            importanceLevel = 3, // Tinggi
            deadlineTimestamp = now + (10 * 24 * 3600 * 1000L), // 10 hari lagi
            isCompleted = false
        )

        val result = SmartPriorityCalculator.calculatePriority(task, currentTimeMillis = now)

        assertEquals(PriorityQuadrant.SCHEDULE, result.quadrant)
        assertTrue(result.urgencyScore < 6.0f)
        assertTrue(result.importanceScore >= 6.0f)
    }

    @Test
    fun testOverdueTaskHasMaxUrgency() {
        val now = 1700000000000L
        val overdueTask = TaskEntity(
            id = 3,
            title = "Laporan Keuangan",
            importanceLevel = 2,
            deadlineTimestamp = now - 10000L, // Sudah lewat
            isCompleted = false
        )

        val result = SmartPriorityCalculator.calculatePriority(overdueTask, currentTimeMillis = now)

        assertEquals(10.0f, result.urgencyScore)
    }
}
