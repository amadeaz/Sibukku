# Add project specific ProGuard rules here.
-dontwarn java.lang.invoke.MethodHandles$Lookup
